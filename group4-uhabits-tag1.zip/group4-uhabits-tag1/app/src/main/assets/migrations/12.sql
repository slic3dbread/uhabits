delete from Score;
delete from Streak;
delete from Checkmarks;